### Features:
+ 0 Javascript
+ 0 Images
+ 0 Icon's
+ 0 3rd Party dependencies

[License](https://github.com/mfleming1989/StarRating-Pure-CSS/blob/master/LICENSE)
